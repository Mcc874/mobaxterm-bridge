---
name: mobaxterm-bridge
description: MobaXterm 终端桥接工具，让 AI 直接读写 MobaXterm 终端。自动识别当前打开的终端窗口（串口/SSH/Telnet 通用），自动搜索日志文件位置，支持发送命令、读取输出、截图、实时跟踪等功能。无需 MobaXterm 专业版，免费版即可使用。
version: 4.2.0
author: chaochen.mu
created_at: 2026-08-27
display_name: MobaXterm 终端桥接
trigger_keywords:
  - 终端
  - 串口
  - MobaXterm
  - 开发板
  - COM口
  - SSH终端
  - 发送命令
  - 读取终端
  - terminal bridge
  - moba 启动
---

# MobaXterm Bridge Skill

通用 MobaXterm 终端桥接工具。自动识别当前打开的终端窗口（不限于特定 COM 口），自动搜索日志文件位置，支持 SSH/串口/Telnet 等所有 MobaXterm 会话类型。

## ⚠️ 使用前必须配置（一次性设置）

### 第一步：配置日志输出

1. MobaXterm 菜单 → **Settings** → **Terminal**
2. 勾选 **"Log terminal output to the following directory"**
3. **Log file name** 设为任意名称（如 `mobaxterm`）
4. **Log type** 选择：**Printable output**（可读文本格式）
5. 点击 **OK** 保存

### 第二步：打开会话

用户在 MobaXterm 中打开需要的会话（串口/SSH/Telnet），脚本会自动识别当前活跃的终端窗口。

### 关于日志续写

MobaXterm 关闭后重新打开会话时，会提示是否继续写入 log，点击"是"即可。脚本会自动检测新会话时间戳并重置读取位置。

## 已知限制与修复措施

### pywinauto send_keys 的限制

1. **依赖前台聚焦** — 发送命令时 MobaXterm 会被置为前台，可能打断用户操作
2. **首字符丢失** — 窗口切换瞬间可能吞掉第一个字符
   - 修复：命令前加前导空格（` ls -la` 而非 `ls -la`）
3. **多命令时序问题** — 连续发送多条命令时可能拼接
   - 修复：每条命令后等待 2 秒，或等待终端提示符出现
4. **无法后台运行** — MobaXterm 最小化/后台时 send_keys 可能失效
   - 建议：发送命令时确保 MobaXterm 窗口可见
5. **特殊字符转义** — 命令中的 `{` `}` 需要 `{{` `}}` 转义
   - 脚本已自动处理

### 窗口聚焦验证

脚本在发送前会验证窗口标题包含 COM/SSH/Telnet 关键词，确保聚焦到了真正的终端窗口而非 MobaXterm 首页或配置窗口。如果检测到错误窗口会输出 WARNING。

## 命令参考

### status - 查看当前状态

```bash
python3 <skill_dir>/scripts/mxt_bridge.py status
```

### read - 读取终端输出

```bash
python3 <skill_dir>/scripts/mxt_bridge.py read              # 增量读取
python3 <skill_dir>/scripts/mxt_bridge.py read --full       # 完整日志
python3 <skill_dir>/scripts/mxt_bridge.py read --lines 50    # 最近N行
```

### send - 发送命令

```bash
python3 <skill_dir>/scripts/mxt_bridge.py send "ls -la"
python3 <skill_dir>/scripts/mxt_bridge.py send "uname -a"
```

### keys - 发送原始按键

```bash
python3 <skill_dir>/scripts/mxt_bridge.py keys "Ctrl+C"
python3 <skill_dir>/scripts/mxt_bridge.py keys "Enter"
```

### interact - 交互模式

```bash
python3 <skill_dir>/scripts/mxt_bridge.py interact "uname -a"
```

### tail - 实时跟踪日志

```bash
python3 <skill_dir>/scripts/mxt_bridge.py tail
```

### screenshot - 截图

```bash
python3 <skill_dir>/scripts/mxt_bridge.py screenshot output.png
```

### logs - 列出日志文件

```bash
python3 <skill_dir>/scripts/mxt_bridge.py logs
```

### reset - 重置读取位置

```bash
python3 <skill_dir>/scripts/mxt_bridge.py reset
```

## 工作原理

```
用户打开任意会话 (串口/SSH/Telnet)
      │
  MobaXterm (统一终端，用户看画面)
      ├── 终端输出 → 日志文件 ← 脚本自动搜索并读取
      └── pywinauto send_keys ← 脚本自动找到窗口并聚焦发送
```

### 发送流程（带修复措施）

```
1. find_terminal_window() → 找到 COM/SSH 窗口（搜索所有窗口，含隐藏的）
2. 验证标题包含 COM/SSH/Telnet → 确认是终端会话窗口
3. SetForegroundWindow() → 聚焦窗口
4. sleep(0.3) → 等待窗口切换稳定
5. send_keys(" command{ENTER}") → 前导空格防首字符丢失
6. sleep(1) → 等待命令写入日志
7. 读日志验证命令是否到达 → 可选确认机制
```

### 读取流程

```
1. find_log_file() → 自动搜索 MobaXterm 安装目录、AppData 等
2. 读取日志 header 时间戳 → 检测是否新会话
3. 如果时间戳变化 → 自动重置读取位置
4. 从上次位置增量读取 → 清理 ANSI 转义码
5. 保存读取位置 → 下次只读新数据
```

## 文件传输（HTTP 中转）

当开发板有网络连接时，优先使用 HTTP 中转方式传输文件。在本地开 HTTP 服务器，开发板用 `wget` 下载。

### 核心原则

**当需要在开发板上运行脚本/代码时，优先在本地（Windows）生成文件，再通过 HTTP 传输到开发板，而不是通过 SSH 终端逐行写入。**

原因：SSH 终端通过 `send_keys` 逐字符发送，遇到中文、特殊字符（`{}`、`$`、引号嵌套）会被转义或破坏，且多行脚本极易出错。本地生成文件再传输，保证内容完整且速度快。

### 原理

```
本地生成文件 → python -m http.server (Windows) → wget/curl (开发板)
```

### 步骤

1. **在本地（Windows）生成文件并启动 HTTP 服务器**：

```bash
# 先用 Write 工具在本地生成脚本文件（如 play.py）
# 然后在文件所在目录启动 HTTP 服务器
cd <文件所在目录>
python -m http.server 8080
```

2. **获取本机 IP**：

```bash
# Windows 上执行
ipconfig | findstr IPv4
# 或从 MobaXterm SSH 会话信息推算（窗口标题含 SSH session to user@<IP>）
# 注意：开发板 IP 和本机 IP 不同，需要的是本机（Windows）IP
```

3. **在开发板上下载文件**：

```bash
# 通过 mxt_bridge.py send 发送到开发板终端
wget http://<LOCAL_IP>:8080/<filename> -O /tmp/<filename>
```

### 注意事项

- **IP 通用性**：每个人开发板和本机 IP 不同，必须先获取本机 IP（`ipconfig`）。SSH 会话信息中通常包含本机 IP（如 MobaXterm 窗口标题 `SSH session to user@10.x.x.x`）
- **中文文件名**：终端可能破坏中文字符，建议先将文件改名为纯英文（如 `copy 原文件.pdf task.pdf`），再传输
- **大文件**：比 base64 方式快几十倍，3MB 文件约 10 秒
- **安全性**：HTTP 服务器仅限局域网内使用，用完及时关闭

## 注意事项

1. **发送时窗口会聚焦** — pywinauto 需要 SetForegroundWindow
2. **单会话** — 建议同一时间只开一个终端会话
3. **日志格式** — Log type 必须选 Printable output
4. **依赖** — pywinauto, pywin32, Pillow
5. **MobaXterm 版本** — 免费版即可，不需要专业版
6. **窗口大小过滤** — 脚本过滤小于 200x150 像素的窗口（tooltip/小窗口）
7. **窗口标题不依赖 "MobaXterm"** — COM5 窗口标题是 `COM5 (USB 串行设备 (COM5))`，不含 "MobaXterm"
