#!/usr/bin/env python3
"""
MobaXterm Bridge v4 - 通用终端桥接工具
通过日志文件读取终端输出 + pywinauto 发送按键
支持 SSH/串口/Telnet 等所有 MobaXterm 会话类型

自动识别日志文件位置，自动聚焦当前打开的终端窗口。
"""
import sys
import os
import time
import argparse
import subprocess
import glob
import json
import re

# === Configuration ===
# 自动发现 MobaXterm 安装路径（支持便携版/安装版），失败时回退默认值
_MOBAXTERM_PATH_CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.mxt_path_cache')

def _detect_mobaxterm_path():
    """检测 MobaXterm.exe 路径。优先级：运行进程 > 缓存 > 扫描便携版位置 > 默认安装路径。"""
    # 1. 从运行进程拿
    try:
        import subprocess
        r = subprocess.run(
            ['powershell', '-Command',
             "Get-Process MobaXterm -ErrorAction SilentlyContinue | Select-Object -Expand Path -First 1"],
            capture_output=True, text=True, timeout=5)
        p = r.stdout.strip().strip(chr(34))
        if p and os.path.exists(p):
            # 缓存到文件，下次进程不在时复用
            try:
                with open(_MOBAXTERM_PATH_CACHE, 'w') as f:
                    f.write(p)
            except Exception:
                pass
            return p
    except Exception:
        pass
    # 2. 用缓存
    try:
        if os.path.exists(_MOBAXTERM_PATH_CACHE):
            with open(_MOBAXTERM_PATH_CACHE) as f:
                p = f.read().strip()
            if p and os.path.exists(p):
                return p
    except Exception:
        pass
    # 3. 扫描常见便携版位置（D 盘根目录的子目录）
    for root in [r'D:\\software2', r'D:\\software', 'D:\\', 'E:\\', 'C:\\']:
        if not os.path.exists(root):
            continue
        try:
            for name in os.listdir(root):
                cand = os.path.join(root, name, 'MobaXterm.exe')
                if os.path.exists(cand):
                    try:
                        with open(_MOBAXTERM_PATH_CACHE, 'w') as f:
                            f.write(cand)
                    except Exception:
                        pass
                    return cand
                # 也可能是直接在 root 下
                cand2 = os.path.join(root, 'MobaXterm.exe')
                if os.path.exists(cand2):
                    try:
                        with open(_MOBAXTERM_PATH_CACHE, 'w') as f:
                            f.write(cand2)
                    except Exception:
                        pass
                    return cand2
        except Exception:
            pass
    # 4. 默认安装路径
    return r"C:\Program Files (x86)\Mobatek\MobaXterm\MobaXterm.exe"

MOBAXTERM_PATH = _detect_mobaxterm_path()
# MobaXterm.exe 所在目录（便携版的 ini 和日志通常在这里）
_MOBAXTERM_DIR = os.path.dirname(MOBAXTERM_PATH) if os.path.exists(MOBAXTERM_PATH) else r"C:\Program Files (x86)\Mobatek\MobaXterm"
# 搜索日志的可能位置（便携版目录优先）
LOG_SEARCH_DIRS = [
    _MOBAXTERM_DIR,                                        # 便携版 exe 同目录
    r"C:\Program Files (x86)\Mobatek\MobaXterm",          # 安装版默认目录
    os.path.join(os.environ.get('APPDATA', ''), 'MobaXterm'),  # AppData
    os.path.join(os.environ.get('USERPROFILE', ''), 'Desktop'),  # 桌面
    os.path.join(os.environ.get('USERPROFILE', ''), 'Documents'),  # 文档
]
WAIT_AFTER_SEND = 2

STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".mxt_state.json")

# === State management ===

def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {}

def save_state(state):
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=2)
    except:
        pass

# === Window management ===

def find_all_windows(include_hidden=False):
    """Find all windows. Returns [(hwnd, title, visible, rect), ...]."""
    import win32gui
    result = []
    def callback(hwnd, _):
        title = win32gui.GetWindowText(hwnd)
        if not title:
            return
        visible = win32gui.IsWindowVisible(hwnd)
        if not include_hidden and not visible:
            return
        try:
            rect = win32gui.GetWindowRect(hwnd)
        except:
            rect = (0, 0, 0, 0)
        result.append((hwnd, title, visible, rect))
    win32gui.EnumWindows(callback, None)
    return result

def find_mobaxterm_windows():
    """Find all MobaXterm related windows (including hidden)."""
    all_wins = find_all_windows(include_hidden=True)
    _exclude = ['edge', 'everything', 'notepad', '记事本', 'passwords', 'settings',
                 'preference', 'about', 'update', 'license', 'registration',
                 'unlock', 'macro', 'tunnelling', 'tunneling', 'configuration',
                 'export', 'import', 'migrat']
    return [(h, t) for h, t, v, r in all_wins
            if 'mobaxterm' in t.lower()
            and not any(kw in t.lower() for kw in _exclude)]

def find_terminal_window():
    """
    Find the currently active terminal window.
    Searches ALL windows (including hidden/minimized) for COM/SSH/Telnet sessions.
    Terminal session windows don't always contain 'MobaXterm' in title - they have COM/SSH/etc.
    Returns (hwnd, title) or (None, None).
    """
    import win32gui
    
    all_wins = find_all_windows(include_hidden=True)
    
    # Session keywords for identifying terminal windows
    session_keywords = ['COM', 'SSH', 'ssh', 'serial', 'telnet']
    # IP 地址正则（匹配 SSH 会话窗口标题如 "10.93.202.174 (avaota)"）
    ip_re = re.compile(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b')

    # Exclude keywords for filtering out non-terminal windows
    exclude_keywords = ['edge', 'everything', 'notepad', '记事本', 'Configuration', 'GDI', 'X server',
                        'passwords', 'settings', 'preference', 'about', 'update', 'license',
                        'registration', 'unlock', 'macro', 'tunnelling', 'tunneling',
                        'session manager', 'export', 'import', 'migrat']

    # Strategy 1: Find windows with session keywords or IP in title (COM/SSH/Telnet/IP)
    # These are actual terminal session windows - don't require 'MobaXterm' in title
    session_wins = []
    for h, t, v, r in all_wins:
        if not t:
            continue
        # Skip windows with exclude keywords
        if any(kw.lower() in t.lower() for kw in exclude_keywords):
            continue
        # Check for session keywords or IP address pattern
        if any(kw in t for kw in session_keywords) or ip_re.search(t):
            w = r[2] - r[0]
            hgt = r[3] - r[1]
            session_wins.append((h, t, v, r, w, hgt))
    
    # 尺寸过滤：MobaXterm 标签窗口最小化/隐藏时尺寸很小（如 158x26），
    # 所以对明确包含 COM/SSH/serial/telnet 关键字的会话窗口放宽阈值（仅过滤 1x1 tooltip）。
    real_sessions = [item for item in session_wins if item[4] >= 2 and item[5] >= 2]
    if real_sessions:
        # 优先选尺寸最大的（通常是最小化前最大的那个标签）
        def area(item):
            return max(0, item[4] * item[5])
        real_sessions.sort(key=area, reverse=True)
        h, t, v, r, w, hgt = real_sessions[0]
        return h, t
    
    # Strategy 2: Any MobaXterm window with reasonable size (might be on home screen)
    mxt_wins = []
    for h, t, v, r in all_wins:
        if not t:
            continue
        if 'mobaxterm' not in t.lower():
            continue
        if any(kw.lower() in t.lower() for kw in exclude_keywords):
            continue
        # 排除路径型标题（如 C:\...\MobaXterm\slash\... 内部进程窗口）
        if '\\' in t or '/' in t or 'slash' in t.lower():
            continue
        w = r[2] - r[0]
        hgt = r[3] - r[1]
        if w >= 200 and hgt >= 150:
            mxt_wins.append((h, t, v, r, w, hgt))
    
    if mxt_wins:
        mxt_wins.sort(key=lambda x: x[4] * x[5], reverse=True)
        h, t, v, r, w, hgt = mxt_wins[0]
        return h, t
    
    # Strategy 3: Session windows even if small (might be minimized)
    if session_wins:
        h, t, v, r, w, hgt = session_wins[0]
        return h, t
    
    return None, None

def ensure_session_open():
    """If no terminal window found, try to open the last session from MobaXterm sidebar."""
    import win32gui
    import win32con
    from pywinauto import Application
    
    # First, find and restore the main MobaXterm window
    mxt_wins = find_mobaxterm_windows()
    if not mxt_wins:
        # MobaXterm not running, start it
        print("MobaXterm not running, starting...")
        subprocess.Popen([MOBAXTERM_PATH])
        time.sleep(5)
        mxt_wins = find_mobaxterm_windows()
        if not mxt_wins:
            print("ERROR: Cannot start MobaXterm.")
            sys.exit(1)
    
    # Find the largest MobaXterm window (main window)
    def get_rect(h):
        try:
            return win32gui.GetWindowRect(h)
        except:
            return (0,0,0,0)
    
    mxt_wins.sort(key=lambda x: (get_rect(x[0])[2]-get_rect(x[0])[0])*(get_rect(x[0])[3]-get_rect(x[0])[1]), reverse=True)
    main_hwnd, main_title = mxt_wins[0]
    
    win32gui.ShowWindow(main_hwnd, win32con.SW_RESTORE)
    win32gui.SetForegroundWindow(main_hwnd)
    time.sleep(1)
    
    # Try to click a session in the sidebar
    try:
        app = Application(backend='uia').connect(handle=main_hwnd)
        win = app.top_window()
        
        # Look for COM/SSH session in sidebar
        for keyword in ['COM5', 'COM4', 'COM3', 'COM', 'SSH', 'serial']:
            try:
                item = win.child_window(title_re=f'.*{keyword}.*', control_type='TreeItem')
                if item.exists(timeout=1):
                    print(f"Opening session: {keyword} from sidebar...")
                    item.double_click_input()
                    time.sleep(3)
                    
                    # Check if terminal window appeared
                    hwnd, title = find_terminal_window()
                    if hwnd:
                        print(f"Session opened: {title[:50]}")
                        return hwnd, title
            except:
                pass
        
        print("No saved sessions found in sidebar. Please open a session manually in MobaXterm.")
        sys.exit(1)
    except Exception as e:
        print(f"Error accessing MobaXterm UI: {e}")
        print("Please open a session manually in MobaXterm.")
        sys.exit(1)

def focus_terminal():
    """Bring terminal window to front. If none found, try to auto-open a session."""
    import win32gui
    import win32con
    
    hwnd, title = find_terminal_window()
    if not hwnd:
        # No terminal window found, try to auto-open
        print("No active terminal window found. Trying to open session...")
        hwnd, title = ensure_session_open()
    
    if not hwnd:
        print("ERROR: Could not find or open a terminal session.")
        print("Please open a session (SSH/Serial/Telnet) in MobaXterm first.")
        sys.exit(1)
    
    # Force restore even if minimized/hidden
    win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
    win32gui.SetForegroundWindow(hwnd)
    time.sleep(0.5)
    return hwnd, title

# === Log file discovery ===

def _read_log_folder_from_ini():
    """从 MobaXterm.ini 读取 LogFolder 设置。
    '<same as MobaXterm executable>' 解析为 exe 同目录。
    返回 (folder, ini_path) 或 (None, None)。
    """
    ini_candidates = [
        os.path.join(_MOBAXTERM_DIR, 'MobaXterm.ini'),
        os.path.join(os.environ.get('APPDATA', ''), 'MobaXterm', 'MobaXterm.ini'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'MobaXterm', 'MobaXterm.ini'),
    ]
    ini_path = next((p_ for p_ in ini_candidates if os.path.exists(p_)), None)
    if not ini_path:
        return None, None
    try:
        with open(ini_path, 'r', encoding='utf-8', errors='replace') as f:
            for line in f:
                if line.startswith('LogFolder='):
                    folder = line.split('=', 1)[1].strip()
                    # '<same as MobaXterm executable>' 表示与 exe 同目录（便携版默认）
                    if folder == '<same as MobaXterm executable>':
                        folder = _MOBAXTERM_DIR
                    return folder, ini_path
    except Exception:
        pass
    return None, ini_path


def _newest_log_in_dir(log_dir, patterns=None):
    """在指定目录下找最新修改的 .log/.txt 文件，返回路径或 None。"""
    if not log_dir or not os.path.exists(log_dir):
        return None
    patterns = patterns or ["*.log"]
    candidates = []
    for pattern in patterns:
        for f in glob.glob(os.path.join(log_dir, pattern)):
            try:
                if not os.path.exists(f):
                    continue
                candidates.append((f, os.path.getmtime(f), os.path.getsize(f)))
            except Exception:
                pass
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[1], reverse=True)
    return candidates[0][0]


def find_log_file():
    """
    自动查找 MobaXterm 日志文件。

    查找顺序（优先级）：
    1. ini 里 LogFolder 的设置（默认 '<same as MobaXterm executable>'
       即便携版 exe 同目录）—— 该目录有日志就用，不再去别处找
    2. fallback 到 LOG_SEARCH_DIRS 其它候选目录（按修改时间取最新）
    """
    # 优先：ini 配置的 LogFolder（默认 = exe 同目录）
    ini_folder, _ini_path = _read_log_folder_from_ini()
    if ini_folder:
        f = _newest_log_in_dir(ini_folder)
        if f:
            return f
    # fallback：遍历其它候选目录，按修改时间取最新
    candidates = []
    for log_dir in LOG_SEARCH_DIRS:
        if not os.path.exists(log_dir):
            continue
        for pattern in ["*.log"]:
            for f in glob.glob(os.path.join(log_dir, pattern)):
                try:
                    if not os.path.exists(f):
                        continue
                    candidates.append((f, os.path.getmtime(f), os.path.getsize(f)))
                except Exception:
                    pass
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[1], reverse=True)
    return candidates[0][0]

def check_and_cleanup_old_log():
    """
    Check if the log file is stale (from a previous MobaXterm session).
    If stale, delete it so MobaXterm creates a fresh one on next session open.
    A log is considered stale if it hasn't been modified in the last 60 seconds
    and the user is trying to send/read.
    """
    log_file = find_log_file()
    if not log_file:
        return
    
    mtime = os.path.getmtime(log_file)
    age = time.time() - mtime
    
    # If log hasn't been updated in >120 seconds and is small, it might be stale
    # But we only clean up if the user explicitly asks via 'reset --clean'
    return log_file

def get_log_dir():
    """Get the directory containing the log file, or default."""
    log_file = find_log_file()
    if log_file:
        return os.path.dirname(log_file)
    return LOG_SEARCH_DIRS[0]

# === Log reading ===

def clean_log_text(text):
    """Remove ANSI escape codes and control characters."""
    ansi_escape = re.compile(r'\x1b\[[0-9;]*[a-zA-Z]')
    text = ansi_escape.sub('', text)
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text)
    return text

def read_log(lines=None, fresh=False):
    """Read terminal output from auto-discovered log file (incremental by default).
    Auto-detects log file recreation by checking the MobaXterm log header timestamp."""
    state = load_state()
    
    log_file = find_log_file()
    if not log_file:
        print("ERROR: Could not find MobaXterm log file.")
        print("\nPlease configure MobaXterm logging:")
        print("  1. MobaXterm → Settings → Terminal")
        print("  2. Enable 'Log terminal output to the following directory'")
        print("  3. Set Log file name (e.g. log or mobaxterm)")
        print("  4. Set Log type: Printable output")
        print("  5. Reopen your session")
        sys.exit(1)
    
    file_key = os.path.basename(log_file)
    current_size = os.path.getsize(log_file)
    current_mtime = os.path.getmtime(log_file)
    
    # Read the log header to check session timestamp
    log_session_ts = None
    try:
        with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
            first_line = f.readline()
            # MobaXterm log header: '=~=~= MobaXterm log 2026.08.27 12:28:41 =~=~='
            m = re.search(r'MobaXterm log (\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})', first_line)
            if m:
                log_session_ts = m.group(1)
    except:
        pass
    
    saved = state.get(file_key, {})
    last_pos = saved.get('pos', 0)
    saved_session_ts = saved.get('session_ts', None)
    
    # Auto-reset conditions:
    # 1. File is smaller than last position (truncated/recreated)
    # 2. Log header timestamp changed (new session)
    # 3. Explicit fresh=True
    if last_pos > current_size:
        last_pos = 0
    elif log_session_ts and saved_session_ts and log_session_ts != saved_session_ts:
        # Log file has a new session timestamp - reset position
        last_pos = 0
    elif fresh:
        last_pos = 0
    elif not fresh and file_key in state:
        last_pos = state[file_key].get('pos', 0)
    else:
        last_pos = 0
    
    try:
        with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
            f.seek(last_pos)
            new_data = f.read()
            new_pos = f.tell()
        
        state[file_key] = {'pos': new_pos, 'file': log_file, 'size': os.path.getsize(log_file), 'mtime': os.path.getmtime(log_file), 'session_ts': log_session_ts}
        save_state(state)
        
        if not new_data.strip():
            with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
                new_data = f.read()
        
        clean_data = clean_log_text(new_data)
        all_lines = clean_data.split('\n')
        while all_lines and not all_lines[-1].strip():
            all_lines.pop()
        
        output_lines = all_lines[-lines:] if lines and lines > 0 else all_lines
        result = '\n'.join(output_lines)
        
        print(f"[Log: {os.path.basename(log_file)} | {os.path.getsize(log_file)} bytes | pos={last_pos}->{new_pos}]")
        return result
    except Exception as e:
        print(f"ERROR reading log: {e}")
        sys.exit(1)

def read_full_log(lines=None):
    """Read full terminal output from log (ignore position tracking)."""
    log_file = find_log_file()
    if not log_file:
        print("ERROR: Could not find MobaXterm log file.")
        print("\nPlease configure MobaXterm logging first.")
        sys.exit(1)
    
    try:
        with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
            data = f.read()
        clean_data = clean_log_text(data)
        all_lines = clean_data.split('\n')
        while all_lines and not all_lines[-1].strip():
            all_lines.pop()
        output_lines = all_lines[-lines:] if lines and lines > 0 else all_lines
        print(f"[Full Log: {os.path.basename(log_file)} | {os.path.getsize(log_file)} bytes]")
        return '\n'.join(output_lines)
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)

# === Command sending ===

def send_command(command, verify=True):
    """Send a command to the currently active MobaXterm terminal.
    Includes anti-garble fixes: leading space, window verification, and optional confirm."""
    hwnd, title = focus_terminal()
    if not hwnd:
        sys.exit(1)
    
    # Verify the window is actually a terminal session (not home/config)
    session_keywords = ['COM', 'SSH', 'ssh', 'serial', 'telnet']
    if not any(kw in title for kw in session_keywords):
        print(f"WARNING: Window '{title[:40]}' may not be a terminal session.")
        print("Make sure a COM/SSH/Telnet session is open in MobaXterm.")
    
    import pywinauto.keyboard as kb
    
    # Fix 1: Escape special characters
    safe_command = command.replace('{', '{{').replace('}', '}}')
    
    # Fix 2: Add leading space to prevent first-char loss
    # (pywinauto sometimes eats the first character during window transition)
    prefix = ' '
    
    try:
        # Fix 3: Focus again right before sending (in case focus was lost)
        import win32gui
        win32gui.SetForegroundWindow(hwnd)
        time.sleep(0.3)
        
        kb.send_keys(prefix + safe_command + '{ENTER}', with_spaces=True)
        print(f"SENT: {command}")
        print(f"[Target: {title[:50]}]")
        
        # Fix 4: Optional verification - read log after send
        if verify:
            time.sleep(1)
            try:
                state = load_state()
                log_file = find_log_file()
                if log_file:
                    file_key = os.path.basename(log_file)
                    last_pos = state.get(file_key, {}).get('pos', 0)
                    with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
                        f.seek(last_pos)
                        new_data = f.read(2000)
                    # Check if the command appears in the log
                    if command[:10] in new_data:
                        # Confirm by updating state
                        return True
            except:
                pass
        return True
    except Exception as e:
        print(f"ERROR sending command: {e}")
        sys.exit(1)

def send_raw_keys(keys):
    """Send raw keystrokes to the currently active MobaXterm terminal."""
    hwnd, title = focus_terminal()
    if not hwnd:
        sys.exit(1)
    
    import pywinauto.keyboard as kb
    
    key_map = {
        'enter': '{ENTER}', 'esc': '{ESC}', 'escape': '{ESC}', 'tab': '{TAB}',
        'ctrl+c': '^c', 'ctrl+z': '^z', 'ctrl+d': '^d', 'ctrl+l': '^l',
        'ctrl+r': '^r', 'ctrl+a': '^a', 'ctrl+e': '^e', 'ctrl+u': '^u',
        'ctrl+k': '^k', 'ctrl+w': '^w',
        'ctrl+shift+a': '^+a', 'ctrl+shift+c': '^+c', 'ctrl+shift+v': '^+v',
        'up': '{UP}', 'down': '{DOWN}', 'left': '{LEFT}', 'right': '{RIGHT}',
        'home': '{HOME}', 'end': '{END}', 'pageup': '{PGUP}', 'pagedown': '{PGDN}',
        'backspace': '{BKSP}', 'delete': '{DEL}', 'space': ' ',
    }
    
    key_lower = keys.lower().strip()
    key_seq = key_map.get(key_lower, keys.replace('{', '{{').replace('}', '}}'))
    
    try:
        kb.send_keys(key_seq, with_spaces=True)
        print(f"KEYS: {keys}")
        print(f"[Target: {title[:50]}]")
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)

# === Screenshot ===

def screenshot(output_path):
    """Take a screenshot of the active terminal window."""
    import win32gui
    import win32ui
    import win32con
    from PIL import Image
    
    hwnd, title = focus_terminal()
    if not hwnd:
        sys.exit(1)
    
    rect = win32gui.GetWindowRect(hwnd)
    l, t, r, b = rect
    w, h = r - l, b - t
    
    hwnd_dc = win32gui.GetWindowDC(hwnd)
    mfc_dc = win32ui.CreateDCFromHandle(hwnd_dc)
    save_dc = mfc_dc.CreateCompatibleDC()
    bitmap = win32ui.CreateBitmap()
    bitmap.CreateCompatibleBitmap(mfc_dc, w, h)
    save_dc.SelectObject(bitmap)
    save_dc.BitBlt((0, 0), (w, h), mfc_dc, (0, 0), win32con.SRCCOPY)
    
    bmpinfo = bitmap.GetInfo()
    bmpstr = bitmap.GetBitmapBits(True)
    img = Image.frombuffer('RGB', (bmpinfo['bmWidth'], bmpinfo['bmHeight']), bmpstr, 'raw', 'BGRX', 0, 1)
    
    abs_path = os.path.abspath(output_path)
    img.save(abs_path, 'PNG')
    
    save_dc.DeleteDC()
    mfc_dc.DeleteDC()
    win32gui.ReleaseDC(hwnd, hwnd_dc)
    print(f"Screenshot saved: {abs_path}")

# === Tail ===

def tail_log(interval=1):
    """Continuously tail the log file."""
    log_file = find_log_file()
    if not log_file:
        print("ERROR: No log file found.")
        sys.exit(1)
    
    print(f"Tailing {log_file} (Ctrl+C to stop)...")
    state = load_state()
    try:
        while True:
            file_key = os.path.basename(log_file)
            last_pos = state.get(file_key, {}).get('pos', 0)
            try:
                with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
                    f.seek(last_pos)
                    new_data = f.read()
                    new_pos = f.tell()
                if new_data:
                    sys.stdout.write(clean_log_text(new_data))
                    sys.stdout.flush()
                state[file_key] = {'pos': new_pos}
                save_state(state)
            except:
                pass
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nStopped.")

# === Misc ===

def list_logs():
    """List all found log files."""
    print("Searching for MobaXterm log files...\n")
    found = False
    for log_dir in LOG_SEARCH_DIRS:
        if not os.path.exists(log_dir):
            continue
        log_files = sorted(glob.glob(os.path.join(log_dir, "*.log")), 
                          key=os.path.getmtime, reverse=True)
        if log_files:
            print(f"{log_dir}:")
            for f in log_files:
                size = os.path.getsize(f)
                mtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(f)))
                print(f"  {os.path.basename(f):40s} {size:>10} bytes  {mtime}")
                found = True
    if not found:
        print("No log files found.")
        print("\nPlease configure MobaXterm logging first.")
    else:
        log_file = find_log_file()
        if log_file:
            print(f"\nActive log: {log_file}")

def show_status():
    """Show current status: window, log file, etc."""
    print("=== MobaXterm Bridge Status ===\n")
    
    # Window
    hwnd, title = find_terminal_window()
    if hwnd:
        print(f"Terminal window: {title[:60]}")
    else:
        mxt = find_mobaxterm_windows()
        if mxt:
            print(f"MobaXterm windows found: {len(mxt)}")
            for h, t in mxt:
                print(f"  - {t[:60]}")
        else:
            print("MobaXterm: NOT RUNNING")
    
    # Log file
    log_file = find_log_file()
    if log_file:
        size = os.path.getsize(log_file)
        mtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(log_file)))
        print(f"Log file: {log_file}")
        print(f"  Size: {size} bytes, Modified: {mtime}")
    else:
        print("Log file: NOT FOUND")
    
    print()

def interact(command):
    """Read output, send command, wait, read again."""
    print("=== BEFORE ===")
    before = read_log(lines=20, fresh=True)
    print(before)
    print()
    send_command(command)
    time.sleep(WAIT_AFTER_SEND)
    print("\n=== AFTER ===")
    after = read_log(lines=50, fresh=True)
    print(after)

# === Main ===

def main():
    parser = argparse.ArgumentParser(
        description='MobaXterm Bridge - Universal AI terminal interface',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Setup (one-time):
  1. MobaXterm → Settings → Terminal → enable "Log terminal output"
  2. Set Log file name (e.g. log or mobaxterm)
  3. Set Log type: Printable output
  4. Open your session (SSH/Serial/Telnet) in MobaXterm

The script auto-detects:
  - Which terminal window is currently active
  - Where the log file is located

Examples:
  %(prog)s status             # Show current status
  %(prog)s read                # Read new terminal output
  %(prog)s read --full         # Read full log
  %(prog)s read --lines 50     # Read last 50 lines
  %(prog)s send "ls -la"       # Send a command
  %(prog)s send "uname -a"     # Send another command
  %(prog)s keys "Ctrl+C"       # Send raw keys
  %(prog)s interact "uname"    # Read → send → read
  %(prog)s reset               # Reset read position
  %(prog)s reset clean         # Truncate old log + reset state
  %(prog)s reopen              # Close & reopen session (fixes stale log)
  %(prog)s tail                # Follow log in real-time
  %(prog)s logs                # List found log files
  %(prog)s screenshot out.png  # Take screenshot
""" % {'prog': '%(prog)s'})
    
    parser.add_argument('action', choices=[
        'status', 'read', 'send', 'keys', 'interact', 'screenshot', 'tail', 'logs', 'reset', 'reopen'
    ], help='Action to perform')
    parser.add_argument('value', nargs='?', default=None,
                        help='Command, key sequence, or output path')
    parser.add_argument('--lines', type=int, default=None,
                        help='Number of lines to read')
    parser.add_argument('--full', action='store_true',
                        help='Read full log (not just new data)')
    parser.add_argument('--wait', type=float, default=WAIT_AFTER_SEND,
                        help='Seconds to wait after sending command')
    
    args = parser.parse_args()
    
    if args.action == 'status':
        show_status()
    elif args.action == 'read':
        output = read_full_log(lines=args.lines) if args.full else read_log(lines=args.lines)
        print(output)
    elif args.action == 'send':
        if not args.value:
            print("ERROR: send needs a command. e.g. send 'ls -la'")
            sys.exit(1)
        send_command(args.value)
        time.sleep(args.wait)
    elif args.action == 'keys':
        if not args.value:
            print("ERROR: keys needs a key sequence. e.g. keys 'Ctrl+C'")
            sys.exit(1)
        send_raw_keys(args.value)
        time.sleep(args.wait)
    elif args.action == 'interact':
        if not args.value:
            print("ERROR: interact needs a command. e.g. interact 'uname -a'")
            sys.exit(1)
        interact(args.value)
    elif args.action == 'screenshot':
        output_path = args.value or 'mobaxterm_screenshot.png'
        screenshot(output_path)
    elif args.action == 'tail':
        tail_log()
    elif args.action == 'logs':
        list_logs()
    elif args.action == 'reset':
        if args.value == 'clean':
            # Truncate old log files and reset state
            log_file = find_log_file()
            if log_file:
                try:
                    # Truncate instead of delete (works even when locked)
                    with open(log_file, 'w') as f:
                        pass
                    print(f"Truncated old log: {log_file}")
                except Exception as e:
                    print(f"Could not truncate log: {e}")
            state = load_state()
            state.clear()
            save_state(state)
            print("State reset and old log truncated.")
            print("Use 'reopen' to close and reopen the session for fresh log.")
        else:
            state = load_state()
            state.clear()
            save_state(state)
            print("State reset. Read position cleared.")
            print("Next 'read' will return full log content.")
    elif args.action == 'reopen':
        # Close current session tab and reopen from sidebar
        import win32gui
        import win32con
        import pywinauto.keyboard as kb
        
        hwnd, title = find_terminal_window()
        if not hwnd:
            print("No terminal window found to reopen.")
            sys.exit(1)
        
        print(f"Current session: {title[:50]}")
        
        # Close the tab (Ctrl+W in MobaXterm)
        win32gui.SetForegroundWindow(hwnd)
        time.sleep(0.5)
        kb.send_keys('^{F4}')  # Ctrl+F4 closes tab in MobaXterm
        print("Closed session tab.")
        time.sleep(2)
        
        # Truncate the old log
        log_file = find_log_file()
        if log_file:
            try:
                with open(log_file, 'w') as f:
                    pass
                print(f"Truncated log: {log_file}")
            except:
                pass
        
        # Reset state
        state = load_state()
        state.clear()
        save_state(state)
        
        # Reopen session from sidebar
        hwnd, title = ensure_session_open()
        if hwnd:
            print(f"Reopened session: {title[:50]}")
            time.sleep(3)
            # Check for new log
            new_log = find_log_file()
            if new_log:
                print(f"New log: {new_log} ({os.path.getsize(new_log)} bytes)")
            else:
                print("Warning: No log file found after reopen.")
        else:
            print("Could not reopen session automatically.")

if __name__ == '__main__':
    main()
