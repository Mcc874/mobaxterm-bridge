---
name: mobaxterm-bridge
description: MobaXterm 终端桥接工具，让 AI 能直接读写 MobaXterm 终端，无需人工复制粘贴。自动识别当前打开的终端窗口（串口/SSH/Telnet 全类型，支持 IP 标题的 SSH 窗口），自动搜索日志文件位置，支持发送命令、增量读取输出、交互执行、原始按键、截图、实时跟踪。AI 本地运行即可远程驱动开发板与服务器，无需在目标设备部署 AI。免费版 MobaXterm 即可使用。
version: 4.3.0
author: chaochen.mu
created_at: 2026-08-27
updated_at: 2026-08-28
display_name: MobaXterm 终端桥接
trigger_keywords:
  - 终端
  - 串口
  - MobaXterm
  - 开发板
  - COM口
  - SSH终端
  - SSH自动化
  - 发送命令
  - 读取终端
  - terminal bridge
  - moba 启动
---

# MobaXterm Bridge Skill

通用 MobaXterm 终端桥接工具。自动识别当前打开的终端窗口（不限于特定 COM 口），自动搜索日志文件位置，支持 SSH/串口/Telnet 等所有 MobaXterm 会话类型。串口与 SSH 会话统一一套命令操作。

## ⚠️ 使用前必须配置（一次性设置）

### 第一步：配置日志输出

**串口/Telnet（全局设置即可）：**

1. MobaXterm 菜单 → **Settings** → **Terminal**
2. 勾选 **"Log terminal output to the following directory"**
3. **Log file name** 设为任意名称（如 `mobaxterm`）
4. **Log type** 选择：**Printable output**（可读文本格式）
5. 点击 **OK** 保存

**SSH 会话（重要：全局设置对 SSH 常不生效，需在会话级单独开启）：**

1. 右键 SSH 会话 → **Edit session**
2. **Terminal settings** 页 → 勾选 **Log terminal output**
3. 日志目录与 Log type 同上（Printable output）
4. 重新打开会话生效

### 第二步：打开会话

用户在 MobaXterm 中打开需要的会话（串口/SSH/Telnet），脚本会自动识别当前活跃的终端窗口。

- 串口窗口标题：`COM3 (USB 串行设备 (COM3))` — 按 COM 关键字识别
- SSH 窗口标题：`10.93.202.174 (user)` 或 `user@host:~` — 按 IP 正则识别（v4.3.0 新增）

### 关于日志续写

MobaXterm 关闭后重新打开会话时，会提示是否继续写入 log，点击"是"即可。脚本会自动检测新会话时间戳并重置读取位置。

## 已知限制与修复措施

### pywinauto send_keys 的限制

1. **依赖前台聚焦** — 发送命令时 MobaXterm 会被置为前台，可能打断用户操作
2. **首字符丢失** — 窗口切换瞬间可能吞掉第一个字符
   - 修复：命令前加前导空格（` ls -la` 而非 `ls -la`）
3. **多命令时序问题** — 连续发送多条命令时可能拼接
   - 修复：每条命令后等待 2 秒，或等待终端提示符出现
4. **无法后台运行** — MobaXterm 最小化/后台时 send_keys 可能失效
   - 建议：发送命令时确保 MobaXterm 窗口可见
5. **特殊字符转义** — 命令中的 `{` `}` 需要 `{{` `}}` 转义
   - 脚本已自动处理

### 窗口聚焦验证

脚本在发送前会验证窗口标题包含 COM/SSH/Telnet 关键词或 IP 地址格式，确保聚焦到了真正的终端窗口而非 MobaXterm 首页或配置窗口。如果检测到错误窗口会输出 WARNING。

## 命令参考

### status - 查看当前状态

```bash
python3 <skill_dir>/scripts/mxt_bridge.py status
```

### read - 读取终端输出

```bash
python3 <skill_dir>/scripts/mxt_bridge.py read              # 增量读取
python3 <skill_dir>/scripts/mxt_bridge.py read --full       # 完整日志
python3 <skill_dir>/scripts/mxt_bridge.py read --lines 50    # 最近N行
```

### send - 发送命令

```bash
python3 <skill_dir>/scripts/mxt_bridge.py send "ls -la"
python3 <skill_dir>/scripts/mxt_bridge.py send "uname -a"
```

### keys - 发送原始按键

```bash
python3 <skill_dir>/scripts/mxt_bridge.py keys "Ctrl+C"
python3 <skill_dir>/scripts/mxt_bridge.py keys "Enter"
```

### interact - 交互模式

```bash
python3 <skill_dir>/scripts/mxt_bridge.py interact "uname -a"
```

### tail - 实时跟踪日志

```bash
python3 <skill_dir>/scripts/mxt_bridge.py tail
```

### screenshot - 截图

```bash
python3 <skill_dir>/scripts/mxt_bridge.py screenshot output.png
```

### logs - 列出日志文件

```bash
python3 <skill_dir>/scripts/mxt_bridge.py logs
```

### reset - 重置读取位置

```bash
python3 <skill_dir>/scripts/mxt_bridge.py reset
```

## 工作原理

```
用户打开任意会话 (串口/SSH/Telnet)
      │
  MobaXterm (统一终端，用户看画面)
      ├── 终端输出 → 日志文件 ← 脚本自动搜索并读取
      └── pywinauto send_keys ← 脚本自动找到窗口并聚焦发送
```

### 发送流程（带修复措施）

```
1. find_terminal_window() → 找到 COM/SSH/IP 标题窗口（搜索所有窗口，含隐藏的）
2. 验证标题含 COM/SSH/Telnet 关键字或 IP 格式 → 确认是终端会话窗口
3. SetForegroundWindow() → 聚焦窗口
4. sleep(0.3) → 等待窗口切换稳定
5. send_keys(" command{ENTER}") → 前导空格防首字符丢失
6. sleep(1) → 等待命令写入日志
7. 读日志验证命令是否到达 → 可选确认机制
```

### 读取流程

```
1. find_log_file() → 自动搜索 MobaXterm 安装目录、AppData 等
2. 读取日志 header 时间戳 → 检测是否新会话
3. 如果时间戳变化 → 自动重置读取位置
4. 从上次位置增量读取 → 清理 ANSI 转义码
5. 保存读取位置 → 下次只读新数据
```

## 实际应用

- **嵌入式串口调试**：读取 U-Boot/内核启动日志，自动发送 bootenv 修改命令并验证
- **SSH 远程运维**：AI 本地运行即可远程驱动开发板/服务器，编译、部署、排障闭环（读输出→分析→执行→验证）
- **自动化测试**：跑测试命令收集结果，失败自动抓取现场
- **交互式流程**：处理 Y/N 确认、密码输入、菜单选择、Ctrl+C 中断
- **长时任务监控**：tail 跟踪编译/训练日志，出错及时处理

## 注意事项

1. **发送时窗口会聚焦** — pywinauto 需要 SetForegroundWindow
2. **单会话** — 建议同一时间只开一个终端会话
3. **日志格式** — Log type 必须选 Printable output
4. **SSH 日志** — 需在会话级单独开启（见上文配置）
5. **依赖** — pywinauto, pywin32, Pillow
6. **MobaXterm 版本** — 免费版即可，不需要专业版
7. **窗口大小过滤** — 脚本过滤小于 200x150 像素的窗口（tooltip/小窗口）
8. **窗口标题不依赖 "MobaXterm"** — COM5 窗口标题是 `COM5 (USB 串行设备 (COM5))`，SSH 窗口标题是 `10.93.202.174 (user)`，均不含 "MobaXterm"

## 变更记录

- **v4.3.0** (2026-08-28)：新增 SSH 会话支持——IP 格式标题窗口识别；排除路径型标题的 MobaXterm 内部窗口误匹配；发送校验支持 IP 标题；补充 SSH 会话级日志配置说明
- **v4.2.0**：通用化窗口识别，支持所有会话类型
